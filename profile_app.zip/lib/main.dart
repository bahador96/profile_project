import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    Color surfaceColor = const Color(0x0dffffff);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        primaryColor: Colors.pink.shade400,
        brightness: Brightness.dark,
        dividerColor: surfaceColor,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.black,
        ),
        scaffoldBackgroundColor: const Color.fromARGB(255, 30, 30, 30),
        textTheme: GoogleFonts.latoTextTheme(
          const TextTheme(
            bodyText2: TextStyle(
              fontSize: 15,
            ),
            bodyText1: TextStyle(
              fontSize: 15,
              color: Color.fromARGB(200, 255, 255, 255),
            ),
            headline6: TextStyle(fontWeight: FontWeight.bold),
            subtitle1: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

enum _SkillType {
  photoshop,
  xd,
  illustrator,
  aftereffect,
  lighrtroom,
}

class _MyHomePageState extends State<MyHomePage> {
  _SkillType _skill = _SkillType.photoshop;
  void updateSelectedSkill(_SkillType skillType) {
    setState(() {
      _skill = skillType;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Curriculum Vitae'),
        actions: const [
          Icon(
            CupertinoIcons.chat_bubble,
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(8, 0, 16, 0),
            child: Icon(
              CupertinoIcons.ellipsis_vertical,
            ),
          ),
        ],
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(32.0),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.asset(
                    'assets/images/profile_image.png',
                    width: 60,
                    height: 60,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Brice Séraphin',
                          style: Theme.of(context).textTheme.subtitle1),
                      const SizedBox(height: 2),
                      const Text('Product& Product Designer'),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            CupertinoIcons.location,
                            size: 14,
                            color: Theme.of(context).textTheme.bodyText1!.color,
                          ),
                          const SizedBox(width: 3),
                          Text(
                            'Paris, France',
                            style: Theme.of(context).textTheme.caption,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Icon(
                  CupertinoIcons.heart,
                  color: Theme.of(context).primaryColor,
                )
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(32, 0, 60, 16),
            child: Text(
              'Enthusiastic young computer Geek, Freelance Designer in love of independence, I have alot of experience in graphical projects, and always give the best of myself to bring you to success.',
              style: Theme.of(context).textTheme.bodyText1,
            ),
          ),
          const Divider(),
          Padding(
            padding: const EdgeInsets.fromLTRB(32, 16, 32, 12),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  'skils',
                  style: Theme.of(context)
                      .textTheme
                      .bodyText2!
                      .copyWith(fontWeight: FontWeight.w900),
                ),
                const SizedBox(width: 2),
                const Icon(
                  CupertinoIcons.chevron_down,
                  size: 12,
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Center(
            child: Wrap(
              spacing: 10,
              runSpacing: 10,
              direction: Axis.horizontal,
              children: [
                Skill(
                  type: _SkillType.photoshop,
                  title: 'Photoshop',
                  imagePath: 'assets/images/app_icon_01.png',
                  shadowColor: Colors.blue,
                  isActive: _skill == _SkillType.photoshop,
                  onTap: () {
                    updateSelectedSkill(_SkillType.photoshop);
                  },
                ),
                Skill(
                  type: _SkillType.xd,
                  title: 'Adobe Xd',
                  imagePath: 'assets/images/app_icon_05.png',
                  shadowColor: Colors.blue,
                  isActive: _skill == _SkillType.xd,
                  onTap: () {
                    updateSelectedSkill(_SkillType.xd);
                  },
                ),
                Skill(
                  type: _SkillType.illustrator,
                  title: 'Illustrator',
                  imagePath: 'assets/images/app_icon_04.png',
                  shadowColor: Colors.pink,
                  isActive: _skill == _SkillType.illustrator,
                  onTap: () {
                    updateSelectedSkill(_SkillType.illustrator);
                  },
                ),
                Skill(
                  type: _SkillType.aftereffect,
                  title: 'After Effect',
                  imagePath: 'assets/images/app_icon_03.png',
                  shadowColor: Colors.orange,
                  isActive: _skill == _SkillType.aftereffect,
                  onTap: () {
                    updateSelectedSkill(_SkillType.aftereffect);
                  },
                ),
                Skill(
                  type: _SkillType.lighrtroom,
                  title: 'Lighrtroom',
                  imagePath: 'assets/images/app_icon_02.png',
                  shadowColor: Colors.blue.shade700,
                  isActive: _skill == _SkillType.lighrtroom,
                  onTap: () {
                    updateSelectedSkill(_SkillType.lighrtroom);
                  },
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

class Skill extends StatelessWidget {
  final _SkillType type;
  final String title;
  final String imagePath;
  final Color shadowColor;
  final bool isActive;
  final Function() onTap;

  const Skill({
    Key? key,
    required this.type,
    required this.title,
    required this.imagePath,
    required this.shadowColor,
    required this.isActive,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: 110,
        height: 110,
        decoration: (isActive)
            ? BoxDecoration(
                color: Theme.of(context).dividerColor,
                borderRadius: BorderRadius.circular(16),
              )
            : null,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              decoration: (isActive)
                  ? BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: shadowColor.withOpacity(0.5),
                          blurRadius: 20,
                        ),
                      ],
                    )
                  : null,
              child: Image.asset(
                imagePath,
                width: 60,
                height: 60,
              ),
            ),
            const Text('Photoshop'),
          ],
        ),
      ),
    );
  }
}

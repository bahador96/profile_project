// import 'package:flutter/animation.dart';

// class SkillItem {
//   final String title;
//   final String imagePath;
//   final Color shadowColor;
//   final bool isActive;


//   SkillItem(
//     this.title,
//     this.imagePath,
//     this.shadowColor,
//     this.isActive,
//   )
// };

